/* File : example.h */

typedef struct {
     double x, y, z;
} Vector;

#include "example.h"

void Foo::bar() {}

